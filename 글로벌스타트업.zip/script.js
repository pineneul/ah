// 슬라이드 기능 구현
// 슬라이드 기능 구현
document.addEventListener('DOMContentLoaded', function () {
    let slides = document.querySelectorAll('.slider .slide');
    let currentSlide = 0;
    const slideInterval = setInterval(nextSlide, 3000); // 3초마다 슬라이드 변경

    function nextSlide() {
        slides[currentSlide].classList.remove('active');
        currentSlide = (currentSlide + 1) % slides.length;
        slides[currentSlide].classList.add('active');
    }

    function goToSlide(n) {
        slides[currentSlide].classList.remove('active');
        currentSlide = (n + slides.length) % slides.length;
        slides[currentSlide].classList.add('active');
    }

    // 슬라이드 전환 버튼 추가 기능이 필요하다면 여기에 추가
});

function openInNewTab(url) {
    const newTab = window.open(url, '_blank');
    if (newTab) {
      newTab.focus();
    } else {
      alert('팝업이 차단되어 새 탭을 열 수 없습니다. 팝업 차단을 해제해주세요.');
    }
  }
  